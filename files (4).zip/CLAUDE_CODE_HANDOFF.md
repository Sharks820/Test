# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║     QAA QUOTE SYSTEM - CLAUDE CODE HANDOFF DOCUMENT                          ║
# ║     Quality Aircraft Accessories - A Hartzell Engine Technologies Company    ║
# ║     January 9, 2026                                                          ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

---

## COMPANY INFORMATION

- **Company:** Quality Aircraft Accessories (QAA)
- **Parent:** Hartzell Engine Technologies  
- **Type:** FAA Part 145 Repair Station - Magneto Overhauls & Aircraft Parts Distribution
- **Address:** 5746 E Apache St, Tulsa, OK 74115
- **Phone:** 918-835-6948
- **Email:** sales@qaainc.com
- **Website:** qaa.com

---

## PROJECT GOAL

Build a **professional Excel-based quote generation system** (.xlsm) that:

1. Generates quotes for 3 different service types (500HR, Customer Property, Exchange)
2. Creates **professional PDFs** with company logo and branding
3. Generates **Outlook emails** with PDF attachments
4. **Logs ALL customer emails** - email address, subject, body, date/time sent
5. Has **REAL clickable button icons** (PNG images with macros assigned - NOT text placeholders)
6. Pulls pricing from part number variants in Parts Master
7. Must look **ULTRA PROFESSIONAL** - this is for a multi-million dollar company

---

## CRITICAL REQUIREMENTS

### 1. BUTTON ICONS
- Generate actual PNG button icons (navy blue with white text, rounded corners)
- Embed them in the Excel sheets
- They must be clickable and have macros assigned
- Button labels needed:
  - GENERATE PDF
  - EMAIL ONLY  
  - CLEAR FORM
  - ◀ MENU
  - UPDATE DATE
  - 500HR SERVICE
  - CUSTOMER PROPERTY
  - EXCHANGE / SALE

### 2. 500HR PRICING - IMPORTANT FIX
- 500HR prices are **NOT flat rate** - each magneto has its own price
- Price is stored in Parts Master with **5H suffix** (NOT -5H)
- Example: Base part "10-382320" → lookup "10-3823205H" for 500HR price
- The suffix is **5H** not **-5H**
- Different magnetos = different 500HR prices:
  ```
  10-3823205H = $575 (S-20/200)
  10-3206805H = $495 (S-1200)
  10-3910885H = $695 (D-2000/D-3000)
  10-1630205H = $625 (Bendix)
  ```

### 3. EMAIL LOGGING
Every email must be logged with:
- Quote Number
- Date Sent
- Time Sent  
- Customer Email Address
- Email Subject
- **Full Email Body Text**
- Quote Type
- Units/Items count
- Total Amount
- Status

---

## QUOTE TYPES

### TYPE 1: 500HR MAGNETO INSPECTION SERVICE

**Purpose:** Quote 500-hour inspection services for customer magnetos

**Capacity:** 6 magnetos per quote

**CHECKBOX FINDINGS SYSTEM:**
- User clicks checkbox to mark findings (☐ → ☑)
- NO TYPING required for findings
- Findings list:
  1. Bad Coil
  2. Bad Capacitor
  3. Bad Distributor Block
  4. Bad Impulse Coupling
  5. Worn Gear
  6. Bad Points
  7. Bad Bearings
  8. Oil in Housing ⚠ (warning - triggers overhaul recommendation)

**PRICING LOGIC:**
- $110 FLAT FEE per unit with ANY findings checked (not per finding)
- 500HR base price from **5H part variant** (NOT -5H)
- If "Ovhl Req?" = Yes:
  - Auto-generate CO part number (10-382320 → 10-382320-CO)
  - Pull CO price from Parts Master
  - CO price REPLACES 500HR fee for that unit

**Fields:**
- Quote #, Date, Customer Email
- Approval Required? (Yes/No dropdown)
- Per unit row: Magneto P/N, Serial #, Description (lookup), 5H Price (lookup), Ovhl Req? (Yes/No), CO P/N (auto-generated), CO Price (lookup), Line Total
- Findings checkbox grid (8 findings × 6 units)
- Notes field
- Totals: 500HR fees + Findings add-on ($110/unit) + Overhaul conversions

---

### TYPE 2: CUSTOMER PROPERTY OVERHAUL

**Purpose:** Quote overhaul labor when customer sends their own unit

**Capacity:** 4 units + 10 O&A (Over & Above) parts

**Features:**
- Auto-detect In-House vs Vendor based on BOM sheet
- Exchange cap reference (shows what OH exchange would cost for comparison)
- Tier discounts: Standard (0%), Tier 1 (7%), Tier 2 (10%), Tier 3 (13%)

**Fields:**
- Quote #, Date, Updated date, Customer Email
- Tier discount dropdown
- Requirements: Approval?, Shipping?, Payment? (Yes/No dropdowns)
- Units section: Unit P/N (with -CO suffix), Description (lookup), Type (auto In-House/Vendor), Base Labor (manual $), Exchange Cap (lookup from -OH variant)
- O&A Parts section: Unit# reference, Part #, Description (lookup), Qty, Unit Price (lookup), Override price, Extended total, Status

---

### TYPE 3: EXCHANGE / INVENTORY SALE

**Purpose:** Quote exchange units or outright sales from QAA inventory

**Capacity:** 12 line items per quote

**Features:**
- Tier-based pricing discounts applied automatically
- Core charge with "Core In Hand" waiver (if customer already sent core, waive charge)
- Auto-lookup all product info from Parts Master

**Fields:**
- Quote #, Date, Customer Email
- Tier discount dropdown
- Requirements: Approval?, Shipping?, Payment?, Core In Hand? (Yes/No)
- Per line item: Part #, Description (lookup), Condition (lookup), Qty, List Price (lookup), Your Price (tiered calc), Extended, Core Charge (lookup, waived if Core In Hand=Yes), Stock (lookup), Lead Time (lookup)
- Totals: Subtotal, Core Total (with waiver note), Your Savings, Grand Total

---

## PART NUMBER SUFFIX SYSTEM

| Suffix | Meaning | Price Column Use |
|--------|---------|------------------|
| (none) | Base part reference | N/A |
| **5H** | 500HR Inspection Service | 500HR sheet pulls this price |
| -CO | Customer Overhaul Labor | Cust Property base labor |
| -OH | Overhauled Exchange Unit | Exchange sheet, also Exchange Cap reference |
| -N | New Unit | Exchange sheet for new sales |

**IMPORTANT:** The 500HR suffix is **5H** (no hyphen before), other suffixes have hyphens.

---

## SHEET STRUCTURE

1. **Menu** - Navigation hub with button icons to each quote type
2. **500HR** - 500HR inspection quotes with checkbox findings
3. **Cust Property** - Customer property overhaul quotes
4. **Exchange** - Exchange/inventory sale quotes
5. **Parts Master** - Product database (Part #, Description, Condition, List Price, Core Charge, Stock, Lead Time, Notes)
6. **BOM** - Bill of Materials (Parent PN, Parent Desc, Component PN, Component Desc, Qty Per)
7. **Inventory** - Stock data from MAPICS
8. **Config** - System settings (Quote Prefix, Next Quote #, Valid Days, 500HR Add-On Fee $110, Tier discounts)
9. **Quote Log** - Quote history with email info
10. **Email Log** - Complete email body records

---

## PDF REQUIREMENTS

The PDF output must be **ULTRA PROFESSIONAL**:

- QAA logo in header (use provided logo files)
- Company tagline: "A Hartzell Engine Technologies Company"
- Full address: 5746 E Apache St, Tulsa, OK 74115
- Contact: 918-835-6948 | sales@qaainc.com | qaa.com
- Quote number and date prominently displayed
- Clean table formatting with borders
- Color scheme: Navy (#1B365D), Sky Blue (#00A3E0), Gold (#FFD966) accents
- Green highlight (#C6EFCE) on totals
- Footer with thank you message and validity note
- Print area set to exclude button rows
- Fit to one page width

---

## EMAIL REQUIREMENTS

Professional email body format:
```
Dear Valued Customer,

Thank you for choosing Quality Aircraft Accessories...

══════════════════════════════════════════════════
QUOTE SUMMARY
══════════════════════════════════════════════════
Quote #:     QAA-00001
Date:        January 9, 2026
Valid:       30 Days

TOTAL:       $X,XXX.XX
══════════════════════════════════════════════════

[Requirements section if applicable]

Best regards,

Quality Aircraft Accessories
A Hartzell Engine Technologies Company
5746 E Apache St, Tulsa, OK 74115
918-835-6948 | sales@qaainc.com | qaa.com
```

---

## VBA MACROS NEEDED

### Navigation:
- GoMenu, Go500HR, GoCustProp, GoExchange

### 500HR Sheet:
- GenPDF500HR - Generate PDF, prompt for email
- Email500HR - Create Outlook email with PDF attached
- Clear500HR - Clear form with confirmation

### Cust Property Sheet:
- GenPDFCustProp
- EmailCustProp  
- ClearCustProp
- UpdateCustPropDate - Update the "Updated" date for revised quotes

### Exchange Sheet:
- GenPDFExchange
- EmailExchange
- ClearExchange

### Logging:
- LogEmail - Write to both Quote Log and Email Log sheets
- Auto-increment quote number after logging

---

## SAMPLE PARTS MASTER DATA

```
Part Number      | Description                           | Cond | List Price | Core  | Stock | Lead Time
-----------------|---------------------------------------|------|------------|-------|-------|----------
10-382320        | S-20/200 Magneto                      | Base | $0         | $0    | 0     |
10-3823205H      | S-20/200 Magneto - 500HR Inspection   | Svc  | $575       | $0    | 0     | 3-5 Days
10-382320-CO     | S-20/200 Magneto - Customer Overhaul  | CO   | $895       | $0    | 0     | 7-10 Days
10-382320-OH     | S-20/200 Magneto - OH Exchange        | OH   | $2,495     | $1,000| 5     | 5-7 Days
10-320680        | S-1200 Magneto                        | Base | $0         | $0    | 0     |
10-3206805H      | S-1200 Magneto - 500HR Inspection     | Svc  | $495       | $0    | 0     | 3-5 Days
10-320680-CO     | S-1200 Magneto - Customer Overhaul    | CO   | $750       | $0    | 0     | 7-10 Days
10-320680-OH     | S-1200 Magneto - OH Exchange          | OH   | $2,095     | $800  | 3     | 5-7 Days
10-391088        | D-2000/D-3000 Magneto                 | Base | $0         | $0    | 0     |
10-3910885H      | D-2000/D-3000 - 500HR Inspection      | Svc  | $695       | $0    | 0     | 3-5 Days
10-391088-CO     | D-2000/D-3000 - Customer Overhaul     | CO   | $1,150     | $0    | 0     | 7-10 Days
10-391088-OH     | D-2000/D-3000 - OH Exchange           | OH   | $2,850     | $1,100| 2     | 5-7 Days
LW-15473         | Impulse Coupling Assembly             | New  | $425       | $0    | 12    | In Stock
10-357170        | Coil Assembly                         | New  | $185       | $0    | 20    | In Stock
10-357210        | Capacitor                             | New  | $45        | $0    | 50    | In Stock
10-51360         | Distributor Block                     | New  | $125       | $0    | 15    | In Stock
10-51350         | Points Assembly                       | New  | $85        | $0    | 30    | In Stock
10-51340         | Bearing Set                           | New  | $95        | $0    | 25    | In Stock
10-51330         | Gear Assembly                         | New  | $165       | $0    | 8     | In Stock
646942-CO        | Governor - Customer Overhaul          | CO   | $1,500     | $0    | 0     | 14-21 Days
646942-OH        | Governor - OH Exchange                | OH   | $3,450     | $1,500| 2     | 5-7 Days
478615-CO        | Turbocharger - Customer Overhaul      | CO   | $2,800     | $0    | 0     | 21-30 Days
478615-OH        | Turbocharger - OH Exchange            | OH   | $5,800     | $2,500| 1     | 5-7 Days
```

---

## CONFIG SETTINGS

| Setting | Value |
|---------|-------|
| Quote Prefix | QAA |
| Next Quote # | 1 |
| Quote Valid Days | 30 |
| 500HR Default Fee | $550 (fallback if 5H part not found) |
| 500HR Add-On FLAT | $110 (per unit with ANY findings) |
| Tier Discounts | Standard 0%, Tier 1 7%, Tier 2 10%, Tier 3 13% |

---

## FORMULA EXAMPLES

### 500HR Price Lookup (5H suffix, NOT -5H):
```excel
=IF(B10="","",IFERROR(VLOOKUP(IF(RIGHT(B10,2)="5H",B10,B10&"5H"),'Parts Master'!$A:$H,4,FALSE),Config!$B$5))
```

### CO Part Number Auto-Generate:
```excel
=IF(F10="Yes",SUBSTITUTE(SUBSTITUTE(B10,"5H",""),"-OH","")&"-CO","")
```

### Findings Add-On Calculation:
```excel
=SUMPRODUCT((COUNTIF(B19:I24,"☑")>0)*1)*Config!B6
```

### Tier Discount Application:
```excel
=IF(E11="","",E11*(1-VLOOKUP($H$6,Config!$A$10:$B$13,2,FALSE)))
```

### Core Waiver:
```excel
=IF($H$7="Yes",0,IFERROR(VLOOKUP(A11,'Parts Master'!$A:$H,5,FALSE),""))
```

---

## DELIVERABLES EXPECTED FROM CLAUDE CODE

1. **QAA_Quote_System.xlsm** - Complete macro-enabled workbook with:
   - All sheets properly structured
   - All formulas working
   - VBA module installed and functional
   - Button icons embedded AND macros assigned
   - Logo embedded in headers
   - Print areas configured
   - Data validation dropdowns working

2. **Professional button icon PNG files** embedded in the workbook

3. **Working VBA code** that:
   - Navigates between sheets
   - Generates PDFs
   - Creates Outlook emails with attachments
   - Logs all emails to Quote Log and Email Log
   - Clears forms
   - Increments quote numbers

---

## LOGO FILES PROVIDED

The user has provided these logo options (use the transparent PNG):
- QAA_Logo_white__2_.png (white version for dark backgrounds)
- 14872712008077.jpg (full color)
- QAA_-_Large.jpg (full color, large)
- QAA_-_Transparent.png (transparent background - USE THIS)

---

## KEY FIXES NEEDED FROM PREVIOUS VERSIONS

1. ✗ 500HR was using "-5H" suffix → ✓ Should be "5H" (no hyphen)
2. ✗ Button icons were text placeholders → ✓ Need real PNG button images with macros
3. ✗ Email logging incomplete → ✓ Must log full email body, customer email, date/time
4. ✗ 500HR was flat rate → ✓ Must pull price from 5H part variant per magneto type

---

## USER FRUSTRATIONS TO AVOID

- "the buttons/icons are not in the sheet" - MUST have actual clickable button images
- "500hr's do not have a set price across the board" - MUST pull from 5H part variant
- "we need to record the email address... and the email we sent" - MUST log complete emails
- "ULTRATHINK this has to be the utmost professionalism" - MUST look professional

---

## TESTING CHECKLIST

- [ ] Enter magneto P/N → 5H price appears automatically
- [ ] Click checkbox → changes from ☐ to ☑
- [ ] Mark findings → $110 add-on calculated per unit
- [ ] Mark Ovhl Req = Yes → CO part# and price appear
- [ ] Click GENERATE PDF button → PDF created with logo
- [ ] Click EMAIL button → Outlook opens with PDF attached
- [ ] Send email → logged to Quote Log and Email Log
- [ ] Quote number increments after send
- [ ] Tier discount applies to Exchange prices
- [ ] Core In Hand = Yes → Core charges show $0

---

## FILES INCLUDED IN HANDOFF

1. **CLAUDE_CODE_HANDOFF.md** - This document
2. **QAA_v11.xlsx** - Current working version (needs fixes above)
3. **MODULE_v11.txt** - Current VBA code
4. **qaa_logo.png** - Logo file for embedding
5. **btn_*.png** - Button icon images

---

END OF HANDOFF DOCUMENT
